module.exports = {
    USER: 'vihtorikallevihtori@gmail.com', 
    PASS: 'jtihh6kd'
}